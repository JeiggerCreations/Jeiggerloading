
fx_version 'cerulean'
game 'gta5'

loadscreen 'index.html'
files {
  'index.html',
  'style.css',
  'assets/overlay_logo.png',
  'assets/welcome_image.png',
  'assets/rules_slide_1.png',
  'assets/rules_slide_2.png',
  'assets/music.mp3'
}
